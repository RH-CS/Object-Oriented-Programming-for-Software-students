package polymorphism;
import java.util.Date;
public class Polymorphism {
	public static void main(String[] args) {

		int accNum = 38694;
		double balance = 2352;
		double ROI = 4.6;
		double overLimit = 690;
		
		Account account1 = new Account();
		checkingsAccount Checkings = new checkingsAccount(accNum, balance, ROI, overLimit);
		accNum = 39734;
		balance = 262;
		ROI = 3.3;
		savingsAccount Savings = new savingsAccount(accNum, balance, ROI);
		
		System.out.println(account1.toString());
		System.out.println(Checkings.toString());
		System.out.println(Savings.toString());
		
	}
}
class Account {
	int accNum = 1111;
	double balance = 100.0;
	double ROI = 2.0;
	Date dateCreated = new Date();
	
	public Account() {
		dateCreated = new Date();
	}
	
	public Account(int accNum, double balance, double ROI) {
		dateCreated = new Date();
		this.accNum = accNum;
		this.balance = balance;
		this.ROI = ROI;
	}
	
	public void deposit(double amount) {
		{this.balance = this.balance + amount;}
	}
	
	public void withdraw(double amount) {
		if(amount < balance) this.balance = this.balance - amount;
	}
	
	public String toString() {
		return "Account " + accNum + " was created on " + dateCreated + " and has $" + balance + " with an interest of " + ROI + "%";
	}
	
}
class checkingsAccount extends Account {
	private double overLimit = 200;
	
	public checkingsAccount() {
		dateCreated = new Date();
	}
	
	public checkingsAccount(int accNum, double balance, double ROI, double overLimit) {
		dateCreated = new Date();
		this.accNum = accNum;
		this.balance = balance;
		this.ROI = ROI;
		this.overLimit = overLimit;
	}
	
	public void withdraw(double amount) {
		if(amount < (balance + overLimit)) {this.balance = this.balance - amount;}
	}
	
	public String toString() {
		return "Account " + accNum + " was created on " + dateCreated + " and has $" + balance + " with an interest of " + ROI + "%, as well as an overdraft limit of $" + overLimit;
	}
}

class savingsAccount extends Account {
	
	public savingsAccount() {
		dateCreated = new Date();	
	}
	
	public savingsAccount(int accNum, double balance, double ROI) {
		dateCreated = new Date();
		this.accNum = accNum;
		this.balance = balance;
		this.ROI = ROI;
	}
}
