import java.util.Scanner;
public class Exercise10_07 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double amount = 0.0;
		final double ACCBAL = 100.0;
		
		Account[] Accounts = new Account[10];
		for(int i = 0; i < Accounts.length; i++) {
			Accounts[i] = new Account(i, ACCBAL); 
		}
		
		System.out.print("Enter Account Id: ");
		int id = input.nextInt();
		
		while(id < 1 || id > 9) {
			System.out.print("Please Enter a Valid Id: ");
			id = input.nextInt();
		}
		
		while(id > 0 && id < 10) {
			int choice = 0;
			do {
				System.out.print("1: View Balance \n2: Withdraw\n3: Deposit\n4: Exit\n");
				choice = input.nextInt();
				
				switch(choice) {
				case 1: System.out.print("Balance: " + Accounts[id].balance + "\n"); break;
				case 2: System.out.print("How much would you like to withdraw? ");
						amount = input.nextDouble(); Accounts[id].withdraw(amount); break;
				case 3: System.out.print("How much would you like to deposit? ");
				amount = input.nextDouble(); Accounts[id].deposit(amount); break;
				case 4: break;
				}
				
			} while(choice >= 1 && choice < 4);
			System.out.print("Enter Account Id: ");
			id = input.nextInt();
			while(id < 0 || id > 9) {
				System.out.print("Please Enter a Valid Id: ");
				id = input.nextInt();
			}
		}
		
	}
}
class Account {
	int id;
	double balance;
	
	Account() {
		id = 0;
		balance = 100.0;
	}
	
	Account(int newId, double newBalance) {
		id = newId;
		balance = newBalance;
	}
	
	int setId(int newId) {
		return id = newId;
	}
	
	void setBal(double newBal) {
		balance = newBal;
	}
	
	double getBal(int id) {
		return balance;
	}
	
	void withdraw(double amount) {
		setBal(balance - amount);
	}
	
	void deposit(double amount) {
		setBal(balance + amount);
	}
	
	
	
}


