package design_class;
import java.util.Scanner;
public class MyInt {
	public static void main(String[] args) {
		int value = 0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an Integer Value: ");
		value = input.nextInt();
		System.out.print("Enter an Integer Value to compare: ");
		int compvalue = input.nextInt();
		
		myInteger Integer1 = new myInteger(value);
		
		System.out.println("Value is " + Integer1.getValue());
		System.out.println("Even? " + Integer1.isEven());
		System.out.println("Odd? " + Integer1.isOdd());
		System.out.println("Prime? " + Integer1.isPrime());
		System.out.println("Even? (static) " + myInteger.isStaticEven(Integer1.value));
		System.out.println("Odd? (static) " + myInteger.isStaticOdd(Integer1.value));
		System.out.println("Prime? (static) " + myInteger.isStaticPrime(Integer1.value));
		System.out.println("Even? (specific) " + myInteger.isSpecificEven(Integer1.value));
		System.out.println("Odd? (specific) " + myInteger.isSpecificOdd(Integer1.value));
		System.out.println("Prime? (specific) " + myInteger.isSpecificPrime(Integer1.value));
		System.out.println("Equals the other value? " + Integer1.equals(compvalue));
		System.out.println("Equals myInt? " + Integer1.equals(Integer1));
		
	}
}
class myInteger{
	int value = 0;
	
	myInteger(int newValue){
		value = newValue;
	}
	
	int getValue() {
		return value;
	}
	
	boolean isEven() {
		boolean even = false;
		if(value % 2 == 0) {even = true;}
		return even;
	}
	boolean isOdd() {
		boolean odd = false;
		if(!(value % 2 == 0)) {odd = true;}
		return odd;
	}
	boolean isPrime() {
		boolean prime = false;
		for(int i = 2; i < value; i++) {
			if(value % i == 0) {
				return prime;
			} else prime = true;
		}
		if(value == 2) {prime = true;}
		return prime;
	}
	
	static boolean isStaticEven(int value) {
		boolean even = false;
		if(value % 2 == 0) {even = true;}
		return even;
	}
	static boolean isStaticOdd(int value) {
		boolean odd = false;
		if(!(value % 2 == 0)) {odd = true;}
		return odd;
	}
	static boolean isStaticPrime(int value) {
		boolean prime = false;
		for(int i = 2; i < value; i++) {
			if(value % i == 0) {
				return prime;
			} else prime = true;
		}
		if(value == 2) {prime = true;}
		return prime;
	}
	
	static boolean isSpecificEven(int myInteger) {
		boolean even = false;
		if(myInteger % 2 == 0) {even = true;}
		return even;
	}
	static boolean isSpecificOdd(int myInteger) {
		boolean odd = false;
		if(!(myInteger % 2 == 0)) {odd = true;}
		return odd;
	}
	static boolean isSpecificPrime(int myInteger) {
		boolean prime = false;
		for(int i = 2; i < myInteger; i++) {
			if(myInteger % i == 0) {
				return prime;
			} else prime = true;
		}
		if(myInteger == 2) {prime = true;}
		return prime;
	}
	
	boolean equals(int value) {
		boolean equals = false;
		if(this.value == value) {
			equals = true;
		}
		return equals;
	}
	boolean specificEquals(int myInteger) {
		boolean equals = false;
		if(this.value == myInteger) {
			equals = true;
		}
		return equals;
	}
	
	static int parseInt(char[] chars) {
		int parsed = 0;
		String buffer = "";
		for(int i = 0; i < chars.length - 1; i++) {
			buffer = buffer + String.valueOf(i);
		}
		Integer.parseInt(buffer);
		return parsed;
	}
	static int parseInt(String string) {
		int parsed = Integer.parseInt(string);
		return parsed;
	}
	
}


